﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Section3
{
    internal class ConvertLength
    {
        // variables
        private double input;

        // property
        public double Input
        {
            get { return input; }
            set { input = value; }
        }


        // methods
        public double MToYd()
        {
            return input * 1.0936;
        }

        public double MToCm()
        {
            return input * 100;
        }

        public double KmToMi()
        {
            return input * 0.6214;
        }

        public double KmToM()
        {
            return input * 1000;
        }
    }
}
