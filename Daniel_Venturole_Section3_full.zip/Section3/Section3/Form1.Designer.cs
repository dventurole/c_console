﻿namespace Section3
{
    partial class frm_ConvertLegth
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBox1 = new System.Windows.Forms.TextBox();
            this.txtBox2 = new System.Windows.Forms.TextBox();
            this.txtBox3 = new System.Windows.Forms.TextBox();
            this.btnMYd = new System.Windows.Forms.Button();
            this.btnKmMile = new System.Windows.Forms.Button();
            this.txtBox6 = new System.Windows.Forms.TextBox();
            this.txtBox5 = new System.Windows.Forms.TextBox();
            this.txtBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(709, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the value of metric length you want to convert";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Metric m :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "cm :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(767, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = ": US yd";
            // 
            // txtBox1
            // 
            this.txtBox1.Location = new System.Drawing.Point(94, 85);
            this.txtBox1.Name = "txtBox1";
            this.txtBox1.Size = new System.Drawing.Size(136, 26);
            this.txtBox1.TabIndex = 0;
            this.txtBox1.Text = "0";
            this.txtBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBox2
            // 
            this.txtBox2.Location = new System.Drawing.Point(289, 85);
            this.txtBox2.Name = "txtBox2";
            this.txtBox2.ReadOnly = true;
            this.txtBox2.Size = new System.Drawing.Size(136, 26);
            this.txtBox2.TabIndex = 5;
            this.txtBox2.TabStop = false;
            this.txtBox2.Text = "0";
            this.txtBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBox3
            // 
            this.txtBox3.Location = new System.Drawing.Point(616, 83);
            this.txtBox3.Name = "txtBox3";
            this.txtBox3.ReadOnly = true;
            this.txtBox3.Size = new System.Drawing.Size(136, 26);
            this.txtBox3.TabIndex = 6;
            this.txtBox3.TabStop = false;
            this.txtBox3.Text = "0";
            this.txtBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnMYd
            // 
            this.btnMYd.Location = new System.Drawing.Point(448, 82);
            this.btnMYd.Name = "btnMYd";
            this.btnMYd.Size = new System.Drawing.Size(149, 29);
            this.btnMYd.TabIndex = 1;
            this.btnMYd.Text = "&1st conversion";
            this.btnMYd.UseVisualStyleBackColor = true;
            this.btnMYd.Click += new System.EventHandler(this.btnMYd_Click);
            // 
            // btnKmMile
            // 
            this.btnKmMile.Location = new System.Drawing.Point(448, 153);
            this.btnKmMile.Name = "btnKmMile";
            this.btnKmMile.Size = new System.Drawing.Size(149, 29);
            this.btnKmMile.TabIndex = 3;
            this.btnKmMile.Text = "&2nd conversion";
            this.btnKmMile.UseVisualStyleBackColor = true;
            this.btnKmMile.Click += new System.EventHandler(this.btnKmMile_Click);
            // 
            // txtBox6
            // 
            this.txtBox6.Location = new System.Drawing.Point(616, 154);
            this.txtBox6.Name = "txtBox6";
            this.txtBox6.ReadOnly = true;
            this.txtBox6.Size = new System.Drawing.Size(136, 26);
            this.txtBox6.TabIndex = 13;
            this.txtBox6.TabStop = false;
            this.txtBox6.Text = "0";
            this.txtBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBox5
            // 
            this.txtBox5.Location = new System.Drawing.Point(289, 156);
            this.txtBox5.Name = "txtBox5";
            this.txtBox5.ReadOnly = true;
            this.txtBox5.Size = new System.Drawing.Size(136, 26);
            this.txtBox5.TabIndex = 12;
            this.txtBox5.TabStop = false;
            this.txtBox5.Text = "0";
            this.txtBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBox4
            // 
            this.txtBox4.Location = new System.Drawing.Point(94, 156);
            this.txtBox4.Name = "txtBox4";
            this.txtBox4.Size = new System.Drawing.Size(136, 26);
            this.txtBox4.TabIndex = 2;
            this.txtBox4.Text = "0";
            this.txtBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(767, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = ": US mile";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(245, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "m :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Metric km :";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(18, 236);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(149, 29);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(690, 237);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 29);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frm_ConvertLegth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 302);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnKmMile);
            this.Controls.Add(this.txtBox6);
            this.Controls.Add(this.txtBox5);
            this.Controls.Add(this.txtBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnMYd);
            this.Controls.Add(this.txtBox3);
            this.Controls.Add(this.txtBox2);
            this.Controls.Add(this.txtBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_ConvertLegth";
            this.Text = "2234583";
            this.Load += new System.EventHandler(this.frm_ConvertLegth_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBox1;
        private System.Windows.Forms.TextBox txtBox2;
        private System.Windows.Forms.TextBox txtBox3;
        private System.Windows.Forms.Button btnMYd;
        private System.Windows.Forms.Button btnKmMile;
        private System.Windows.Forms.TextBox txtBox6;
        private System.Windows.Forms.TextBox txtBox5;
        private System.Windows.Forms.TextBox txtBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

