﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


// Daniel Venturole
// Midterm
// 02/03/2023

// An application to perform conversions from metric to imperial system

namespace Section3
{
    public partial class frm_ConvertLegth : Form
    {
        public frm_ConvertLegth()
        {
            InitializeComponent();
        }

        private void btnMYd_Click(object sender, EventArgs e)
        {
            try
            {
                ConvertLength operation = new ConvertLength(); // initialize the constructor
                operation.Input = Convert.ToDouble(txtBox1.Text);
                txtBox2.Text = operation.MToCm().ToString(); // converts m to cm
                txtBox3.Text = operation.MToYd().ToString(); // converts m to yd
                txtBox1.ReadOnly = true;
                txtBox4.Focus();
            }
            catch
            {
                MessageBox.Show("Input string was not in a correct format", "", MessageBoxButtons.OK); // Show system error message
                txtBox1.Focus(); // places cursor back to txtBox1
                txtBox1.Text = "0"; // returns to default value
            }


        }

        private void btnKmMile_Click(object sender, EventArgs e)
        {
            try
            {
                ConvertLength operation = new ConvertLength(); // initialize the constructor
                operation.Input = Convert.ToDouble(txtBox4.Text);
                txtBox5.Text = operation.KmToM().ToString(); // converts m to cm
                txtBox6.Text = operation.KmToMi().ToString(); // converts m to yd
                txtBox4.ReadOnly = true;

            }
            catch
            {
                MessageBox.Show("Input string was not in a correct format", "", MessageBoxButtons.OK); // Show system error message
                txtBox4.Focus(); // places cursor back to txtBox1
                txtBox4.Text = "0"; // returns to default value
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //reset values and properties
            txtBox1.Text = "0"; // 
            txtBox1.ReadOnly = false;
            txtBox1.Focus();
            txtBox2.Text = "0";
            txtBox3.Text = "0";
            txtBox4.Text = "0";
            txtBox4.ReadOnly = false;
            txtBox5.Text = "0";
            txtBox6.Text = "0";
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you want to exit the app?", "Exit", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                this.Close();
            }

        }

        private void frm_ConvertLegth_Load(object sender, EventArgs e)
        {
            //reset values and properties
            txtBox1.Text = "0"; // 
            txtBox1.ReadOnly = false;
            txtBox1.Focus();
            txtBox2.Text = "0";
            txtBox3.Text = "0";
            txtBox4.Text = "0";
            txtBox4.ReadOnly = false;
            txtBox5.Text = "0";
            txtBox6.Text = "0";
        }
    }
}
